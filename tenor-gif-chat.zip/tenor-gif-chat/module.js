{
  "name": "tenor-gif-chat",
  "title": "Tenor GIF Chat Button",
  "description": "Adiciona um botão lateral que permite pesquisar e enviar GIFs da Tenor para o chat.",
  "version": "1.0",
  "author": "Caio e ChatGPT",
  "minimumCoreVersion": "12",
  "compatibleCoreVersion": "12",
  "scripts": ["scripts/main.js"],
  "manifest": "https://chelryse.github.io/tenor-gif-chat/module.json",
  "download": "https://chelryse.github.io/tenor-gif-chat/tenor-gif-chat.zip",
  "url": "https://github.com/chelryse/tenor-gif-chat"
}
