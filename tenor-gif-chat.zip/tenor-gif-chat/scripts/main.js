Hooks.once("init", () => {
  console.log("Tenor GIF Chat Module | Iniciado");
});

Hooks.once("ready", () => {
  const control = {
    name: "tenorGifButton",
    title: "GIFs da Tenor",
    icon: "fas fa-photo-video",
    button: true,
    onClick: () => showGifSearch(),
    visible: () => true
  };

  ui.controls.controls.push({
    name: "tenor-gif",
    title: "Tenor GIF",
    icon: "fas fa-film",
    tools: [control]
  });

  ui.controls.render();
});

async function showGifSearch() {
  const content = `
    <div style="margin-bottom: 10px;">
      <input type="text" id="tenor-search-input" placeholder="Buscar GIF..." style="width: 100%; padding: 5px;" />
    </div>
    <div id="tenor-results" style="display: flex; flex-wrap: wrap; gap: 5px; max-height: 300px; overflow-y: auto;"></div>
  `;

  new Dialog({
    title: "Buscar GIF da Tenor",
    content,
    buttons: { fechar: { label: "Fechar" } },
    render: html => {
      const input = html.find("#tenor-search-input");
      const results = html.find("#tenor-results");

      input.on("input", async () => {
        const query = input.val();
        if (!query) return;

        const apiKey = "AIzaSyDh3NhHK6ZS51pPknk2v_8WuOa4apM2e9E";
        const url = `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(query)}&key=${apiKey}&limit=10&media_filter=gif&contentfilter=high`;
        const res = await fetch(url);
        const data = await res.json();

        results.empty();
        for (const r of data.results) {
          const gif = r.media_formats.gif.url;
          const img = $(`<img src="${gif}" width="100" style="cursor: pointer;" />`);
          img.on("click", () => {
            ChatMessage.create({ content: `<img src="${gif}" />` });
          });
          results.append(img);
        }
      });
    },
    default: "fechar"
  }).render(true);
}
